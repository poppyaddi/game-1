<?php
namespace app\port\model;

use think\Model;

class StoreLog extends Model
{
    protected $autoWriteTimestamp = 'datetime';
}