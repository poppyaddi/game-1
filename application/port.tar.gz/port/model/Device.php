<?php
namespace app\port\model;

use think\Model;

class Device extends Model
{
    protected $autoWriteTimestamp = 'datetime';
}