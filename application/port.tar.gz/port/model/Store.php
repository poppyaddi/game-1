<?php
namespace app\port\model;

use think\Model;

class Store extends Model
{
    protected $autoWriteTimestamp = 'datetime';
}