<?php
namespace app\port\model;

use think\Model;

class Games extends Model
{
    protected $autoWriteTimestamp = 'datetime';
}